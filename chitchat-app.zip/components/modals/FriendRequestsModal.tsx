
import React from 'react';
import { CheckIcon, XIcon } from '../icons/Icons';

interface FriendRequestsModalProps {
  onClose: () => void;
}

const FriendRequestItem: React.FC<{ name: string; avatar: string }> = ({ name, avatar }) => (
  <div className="flex items-center justify-between p-3">
    <div className="flex items-center">
      <img src={avatar} alt={name} className="w-10 h-10 rounded-full" />
      <div className="ml-3">
        <p className="font-semibold">{name}</p>
        <p className="text-sm text-gray-500">Want to make friend with you</p>
      </div>
    </div>
    <div className="flex space-x-2">
      <button className="p-2 rounded-full text-green-500 bg-green-100 hover:bg-green-200">
        <CheckIcon />
      </button>
      <button className="p-2 rounded-full text-red-500 bg-red-100 hover:bg-red-200">
        <XIcon />
      </button>
    </div>
  </div>
);

const FriendRequestsModal: React.FC<FriendRequestsModalProps> = ({ onClose }) => {
  // Mock data for friend requests
  const requests = [
    { name: 'Nguyen Van A', avatar: 'https://picsum.photos/seed/nguyenvana/48/48' },
    { name: 'Nguyen Van B', avatar: 'https://picsum.photos/seed/nguyenvanb/48/48' },
    { name: 'Nguyen Van C', avatar: 'https://picsum.photos/seed/nguyenvanc/48/48' },
  ];

  return (
    <div className="fixed top-20 right-6 z-50">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm border border-pink-200">
        <div className="p-4 border-b border-pink-200">
            <h2 className="text-xl font-bold text-pink-500">Friend Requests</h2>
        </div>
        <div className="p-2 divide-y divide-pink-100">
          {requests.map((req, i) => (
            <FriendRequestItem key={i} name={req.name} avatar={req.avatar} />
          ))}
        </div>
         <div className="p-2">
             <button onClick={onClose} className="w-full text-sm text-gray-500 hover:text-pink-500">Close</button>
         </div>
      </div>
    </div>
  );
};

export default FriendRequestsModal;
