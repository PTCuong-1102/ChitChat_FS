
import React from 'react';
import SignInForm from './SignInForm';
import SignUpForm from './SignUpForm';

interface AuthPageProps {
  mode: 'signIn' | 'signUp';
  onAuthSuccess: () => void;
  switchMode: (mode: 'signIn' | 'signUp') => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ mode, onAuthSuccess, switchMode }) => {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-full max-w-6xl mx-auto p-8">
        <div className="bg-white rounded-2xl shadow-2xl flex flex-col md:flex-row overflow-hidden">
          <div className="w-full md:w-1/2 p-12 flex flex-col justify-center bg-pink-50">
            <h1 className="text-5xl font-bold text-pink-500 mb-4">
              Welcome to <br /> ChitChat App
            </h1>
            <p className="text-gray-600">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
          </div>
          <div className="w-full md:w-1/2 p-12">
            {mode === 'signIn' ? (
              <SignInForm onAuthSuccess={onAuthSuccess} onSwitchToSignUp={() => switchMode('signUp')} />
            ) : (
              <SignUpForm onAuthSuccess={onAuthSuccess} onSwitchToSignIn={() => switchMode('signIn')} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
