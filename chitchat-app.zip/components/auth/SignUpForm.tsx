
import React from 'react';

interface SignUpFormProps {
  onAuthSuccess: () => void;
  onSwitchToSignIn: () => void;
}

const InputField: React.FC<{ label: string; type: string }> = ({ label, type }) => (
  <div className="mb-4">
    <label className="block text-pink-500 text-sm font-bold mb-2">{label}:</label>
    <input
      type={type}
      className="w-full px-4 py-3 rounded-lg bg-white border border-pink-200 focus:border-pink-500 focus:outline-none transition-colors"
    />
  </div>
);

const SignUpForm: React.FC<SignUpFormProps> = ({ onAuthSuccess, onSwitchToSignIn }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAuthSuccess();
  };

  return (
    <div className="w-full max-w-sm mx-auto">
      <h2 className="text-3xl font-bold text-pink-500 mb-6 text-center">Sign up</h2>
      <form onSubmit={handleSubmit}>
        <InputField label="Full Name" type="text" />
        <InputField label="User Name" type="text" />
        <InputField label="Email" type="email" />
        <InputField label="Password" type="password" />
        <button
          type="submit"
          className="w-full bg-pink-500 hover:bg-pink-600 text-white font-bold py-3 px-4 rounded-lg transition-colors mt-4"
        >
          Sign up
        </button>
      </form>
      <p className="text-center text-gray-500 text-sm mt-6">
        Have an account?{' '}
        <button onClick={onSwitchToSignIn} className="text-pink-500 hover:underline font-bold">
          Sign in now
        </button>
      </p>
    </div>
  );
};

export default SignUpForm;
