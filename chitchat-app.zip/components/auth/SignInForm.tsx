
import React from 'react';

interface SignInFormProps {
  onAuthSuccess: () => void;
  onSwitchToSignUp: () => void;
}

const InputField: React.FC<{ label: string; type: string }> = ({ label, type }) => (
  <div className="mb-6">
    <label className="block text-pink-500 text-sm font-bold mb-2">{label}:</label>
    <input
      type={type}
      className="w-full px-4 py-3 rounded-lg bg-white border border-pink-200 focus:border-pink-500 focus:outline-none transition-colors"
    />
  </div>
);

const SignInForm: React.FC<SignInFormProps> = ({ onAuthSuccess, onSwitchToSignUp }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAuthSuccess();
  };

  return (
    <div className="w-full max-w-sm mx-auto">
      <h2 className="text-3xl font-bold text-pink-500 mb-8 text-center">Sign in</h2>
      <form onSubmit={handleSubmit}>
        <InputField label="Email" type="email" />
        <InputField label="Password" type="password" />
        <button
          type="submit"
          className="w-full bg-pink-500 hover:bg-pink-600 text-white font-bold py-3 px-4 rounded-lg transition-colors"
        >
          Sign in
        </button>
      </form>
      <p className="text-center text-gray-500 text-sm mt-6">
        Don't have an account?{' '}
        <button onClick={onSwitchToSignUp} className="text-pink-500 hover:underline font-bold">
          Sign up now
        </button>
      </p>
    </div>
  );
};

export default SignInForm;
