import React, { useState, useCallback } from 'react';
import ServerList from './ServerList';
import Sidebar from './Sidebar';
import Header from './Header';
import ChatView from './ChatView';
import FriendsView from './FriendsView';
import { CHATS, USERS, CURRENT_USER, AI_BOTS } from '../../constants';
import { Chat, User, Message } from '../../types';
import { getGeminiResponse } from '../../services/geminiService';
import CreateGroupModal from '../modals/CreateGroupModal';
import { UserProfileModal } from '../modals/UserProfileModal';
import FriendRequestsModal from '../modals/FriendRequestsModal';
import ConfigureAIBotModal from '../modals/ConfigureAIBotModal';
import ChatManagementPanel from './ChatManagementPanel';

type View = 'friends' | 'chat';
type Modal = 'createGroup' | 'userProfile' | 'friendRequests' | 'configureAIBot' | null;
type FriendshipStatus = 'friends' | 'request_sent' | 'not_friends';

const ChatInterface: React.FC<{ onSignOut: () => void }> = ({ onSignOut }) => {
  const [activeServerId, setActiveServerId] = useState<string>('home');
  const [view, setView] = useState<View>('friends');
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [chats, setChats] = useState<Chat[]>(CHATS);
  const [users, setUsers] = useState<User[]>(USERS);
  const [currentUser, setCurrentUser] = useState<User>(CURRENT_USER);
  const [modal, setModal] = useState<Modal>(null);
  const [bots, setBots] = useState<User[]>(AI_BOTS);
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [isManagementPanelOpen, setManagementPanelOpen] = useState(false);
  
  const [friendshipStatus, setFriendshipStatus] = useState<Record<string, FriendshipStatus>>(() => {
    const initialStatus: Record<string, FriendshipStatus> = {};
    USERS.forEach(user => {
        if (user.id === CURRENT_USER.id) return;
        const isFriend = CHATS.some(chat => 
            chat.type === 'dm' && 
            !chat.isBotChat &&
            chat.participants.some(p => p.id === user.id)
        );
        initialStatus[user.id] = isFriend ? 'friends' : 'not_friends';
    });
    return initialStatus;
  });
  const [addFriendSearchResult, setAddFriendSearchResult] = useState<User | 'not_found' | null>(null);

  const activeChat = chats.find(c => c.id === activeChatId) || null;
  const regularChats = chats.filter(c => !c.isBotChat);

  const handleSelectChat = (chatId: string) => {
    setActiveChatId(chatId);
    setView('chat');
    setManagementPanelOpen(false);
  };

  const handleSelectServer = (serverId: string) => {
    setActiveServerId(serverId);
    setManagementPanelOpen(false);
    if (serverId === 'home') {
      setView('friends');
      setActiveChatId(null);
      setSearchQuery('');
    } else {
      const botChat = chats.find(c => c.isBotChat && c.participants.some(p => p.id === serverId));
      if (botChat) {
        setActiveChatId(botChat.id);
        setView('chat');
      }
    }
  };
  
  const handleShowFriends = () => {
      setActiveServerId('home');
      setActiveChatId(null);
      setView('friends');
      setSearchQuery('');
      setManagementPanelOpen(false);
  }

  const handleSendMessage = useCallback(async (text: string, type: Message['type'] = 'text') => {
    if (!activeChat) return;

    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      senderId: currentUser.id,
      text,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
      type,
    };

    const updatedChats = chats.map(chat => {
      if (chat.id === activeChat.id) {
        return { ...chat, messages: [...chat.messages, newMessage] };
      }
      return chat;
    });

    setChats(updatedChats);
    setActiveChatId(activeChat.id);

    if (activeChat.isBotChat) {
        const bot = activeChat.participants.find(p => p.isBot);
        if (!bot) return;

        let botResponseText = "I'm sorry, this bot provider is not supported yet.";

        if (bot.provider === 'gemini') {
            const apiKey = apiKeys[bot.id];
            const botModel = bot.model || 'gemini-2.5-flash';
            botResponseText = await getGeminiResponse(text, botModel, apiKey);
        }
        
        const botMessage: Message = {
            id: `msg-${Date.now() + 1}`,
            senderId: bot.id,
            text: botResponseText,
            timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
            type: 'text',
        };
        const finalChats = updatedChats.map(chat => {
            if (chat.id === activeChat.id) {
                return { ...chat, messages: [...chat.messages, botMessage] };
            }
            return chat;
        });
        setChats(finalChats);
        setActiveChatId(activeChat.id);
    }
  }, [activeChat, chats, apiKeys, currentUser.id]);

  const handleConfigureBot = (botName: string, model: string, provider: string, apiKey: string) => {
    const newBotId = `user-bot-${Date.now()}`;
    const newChatId = `chat-bot-${Date.now()}`;

    const newBot: User = {
      id: newBotId,
      name: botName,
      username: botName.toLowerCase().replace(/\s/g, '-'),
      avatar: `https://ui-avatars.com/api/?name=${botName.charAt(0)}&background=random&color=fff`,
      email: '',
      status: 'online',
      isBot: true,
      model: model,
      provider: provider,
    };

    const newChat: Chat = {
      id: newChatId,
      type: 'dm',
      name: botName,
      participants: [currentUser, newBot],
      messages: [{
          id: `msg-${Date.now()}`,
          senderId: newBot.id,
          text: `Hello! I am ${botName}. How can I assist you?`,
          timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
          type: 'text',
      }],
      isBotChat: true,
      lastMessagePreview: `Hello! I am ${botName}.`,
    };

    setBots(prevBots => [...prevBots, newBot]);
    setChats(prevChats => [...prevChats, newChat]);
    setApiKeys(prevKeys => ({...prevKeys, [newBotId]: apiKey}));
  };

  const handleUpdateProfile = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    setUsers(prevUsers => prevUsers.map(u => u.id === updatedUser.id ? updatedUser : u));
    setChats(prevChats => prevChats.map(chat => ({
        ...chat,
        participants: chat.participants.map(p => p.id === updatedUser.id ? updatedUser : p)
    })));
  };

  const handleSearchFriend = (searchTerm: string) => {
    const term = searchTerm.toLowerCase().trim();
    if (!term) {
        setAddFriendSearchResult(null);
        return;
    }
    const foundUser = users.find(u => u.username.toLowerCase() === term || u.email.toLowerCase() === term);
    setAddFriendSearchResult(foundUser || 'not_found');
  };

  const handleAddFriend = (friendId: string) => {
      setFriendshipStatus(prevStatus => ({
          ...prevStatus,
          [friendId]: 'request_sent'
      }));
  };
  
  const handleGroupAction = (chatId: string, action: 'removeUser' | 'changeRole' | 'leave', payload: { userId?: string, newRole?: 'admin' | 'member' }) => {
    setChats(prevChats => prevChats.map(chat => {
      if (chat.id !== chatId) return chat;

      let newParticipants = [...chat.participants];
      let newRoles = { ...chat.roles };

      switch(action) {
        case 'removeUser':
          if (payload.userId) {
            newParticipants = chat.participants.filter(p => p.id !== payload.userId);
            delete newRoles[payload.userId];
          }
          break;
        case 'changeRole':
          if (payload.userId && payload.newRole && newRoles) {
            newRoles[payload.userId] = payload.newRole;
          }
          break;
        case 'leave':
          newParticipants = chat.participants.filter(p => p.id !== currentUser.id);
          delete newRoles[currentUser.id];
          break;
      }
      
      return { ...chat, participants: newParticipants, roles: newRoles };
    }));

    if (action === 'leave') {
        setActiveChatId(null);
        setView('friends');
    }
  };


  return (
    <div className="h-screen w-screen flex text-gray-800">
      <ServerList 
        bots={bots}
        activeServerId={activeServerId}
        onSelectServer={handleSelectServer}
        onAddBot={() => setModal('configureAIBot')}
      />
      {activeServerId === 'home' && (
        <Sidebar
          chats={regularChats}
          onSelectChat={handleSelectChat}
          activeChatId={activeChatId}
          onShowFriends={handleShowFriends}
          openCreateGroupModal={() => setModal('createGroup')}
          currentUser={currentUser}
          onSignOut={onSignOut}
          onOpenProfile={() => setModal('userProfile')}
        />
      )}
      <div className="flex flex-col flex-grow bg-white relative overflow-hidden">
        <Header 
            activeChat={activeChat} 
            view={view} 
            onShowFriendRequests={() => setModal('friendRequests')}
            searchQuery={searchQuery}
            onSearchChange={(e) => setSearchQuery(e.target.value)}
            onToggleManagementPanel={() => setManagementPanelOpen(prev => !prev)}
        />
        <main className="flex-grow overflow-y-auto bg-white/70">
          {view === 'friends' && activeServerId === 'home' && (
            <FriendsView 
                users={users.filter(u => u.id !== currentUser.id)}
                searchQuery={searchQuery}
                friendshipStatus={friendshipStatus}
                addFriendSearchResult={addFriendSearchResult}
                onSearchFriend={handleSearchFriend}
                onAddFriend={handleAddFriend}
                currentUser={currentUser}
            />
          )}
          {view === 'chat' && activeChat && (
            <ChatView
              chat={activeChat}
              onSendMessage={handleSendMessage}
              currentUser={currentUser}
              users={[...users, ...bots]}
            />
          )}
        </main>
        {isManagementPanelOpen && activeChat && (
            <ChatManagementPanel 
                chat={activeChat}
                currentUser={currentUser}
                users={users}
                onClose={() => setManagementPanelOpen(false)}
                onGroupAction={handleGroupAction}
            />
        )}
      </div>
      {modal === 'createGroup' && <CreateGroupModal onClose={() => setModal(null)} users={users} />}
      {modal === 'userProfile' && (
        <UserProfileModal 
          onClose={() => setModal(null)} 
          user={currentUser} 
          onUpdateProfile={handleUpdateProfile}
        />
      )}
      {modal === 'friendRequests' && <FriendRequestsModal onClose={() => setModal(null)} />}
      {modal === 'configureAIBot' && <ConfigureAIBotModal onClose={() => setModal(null)} onConfigure={handleConfigureBot} />}
    </div>
  );
};

export default ChatInterface;