
import React, { useState } from 'react';
import AuthPage from './components/auth/AuthPage';
import ChatInterface from './components/chat/ChatInterface';

type AuthState = 'signIn' | 'signUp' | 'authenticated';

function App() {
  const [authState, setAuthState] = useState<AuthState>('signUp');

  const handleAuthSuccess = () => {
    setAuthState('authenticated');
  };

  const handleSignOut = () => {
    setAuthState('signIn');
  };

  const switchAuthMode = (mode: 'signIn' | 'signUp') => {
    setAuthState(mode);
  }

  return (
    <div className="min-h-screen bg-pink-50 font-sans">
      {authState !== 'authenticated' ? (
        <AuthPage 
          mode={authState} 
          onAuthSuccess={handleAuthSuccess} 
          switchMode={switchAuthMode}
        />
      ) : (
        <ChatInterface onSignOut={handleSignOut} />
      )}
    </div>
  );
}

export default App;
