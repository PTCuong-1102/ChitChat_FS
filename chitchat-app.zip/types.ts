export interface User {
  id: string;
  name: string;
  username: string;
  avatar: string;
  email: string;
  status: 'online' | 'offline' | 'away';
  activity?: string;
  isBot?: boolean;
  model?: string;
  provider?: string;
  dob?: string;
  socials?: {
    facebook?: string;
    linkedin?: string;
    zalo?: string;
  };
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  type: 'text' | 'image' | 'link';
}

export interface Chat {
  id: string;
  type: 'dm' | 'group';
  name: string;
  participants: User[];
  messages: Message[];
  avatar?: string;
  lastMessagePreview?: string;
  isBotChat?: boolean;
  creatorId?: string;
  roles?: { [key: string]: 'admin' | 'member' };
}
